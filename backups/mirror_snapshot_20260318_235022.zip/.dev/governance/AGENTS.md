# AGENTS.md
## Mirror Box Orchestrator — Autonomous Agent Governance (v1.1)

**Scope:** This document governs MBO's internal development pipeline only.
It does not govern generated client project policy files (for example, .mbo/AGENTS.md).

---

## Section 1 — Session Start Protocol

Every development session begins in this order. No exceptions.

1. Read this file (`.dev/governance/AGENTS.md`)
2. Read `.dev/governance/projecttracking.md` — identify current milestone and active task (single source of truth)
3. Read `.dev/governance/BUGS.md` — check linked P0/P1 blockers for the active task

No code is written before this sequence completes.

---

## Section 2 — Development Protocol (DID) & Routing Tiers

**Every task must exist in `projecttracking.md` before code is written.**

The agents are interchangeable peers. Before executing a task, the human Operator
determines the Routing Tier:

**Tier 0 & 1 (Low Risk / Single File / Docs):**
- A single agent proposes the implementation and writes the diff.
- If the human approves, that agent implements it directly.

**Tier 2 & 3 (High Risk / Multi-File / Architecture / Governance):** (Dual Independent Derivation)
1. Any modification to `SPEC.md`, `AGENTS.md`, or the governance directory.
2. **Agent A** proposes the implementation and writes the diff.
3. **Agent B** MUST independently derive their own implementation BLIND — no Agent A output visible.
4. The human Operator reconciles the two versions.
5. Only after reconciliation and human "go" is the implementation committed.
6. If unresolvable: one conflict-zone retry, then Codex as tiebreaker.

Full protocol: `.dev/governance/DID-PROTOCOL.pdf`
Implementation task: `1.1-H24` — see `.dev/preflight/did-protocol-implementation.md`

---

## Section 3 — Authorship & Attribution Policy

1. **Authorship is for the Architect:** No agent shall claim authorship credit on
   commit pushes, pull requests, or documentation.
2. **No "AI-Generated" Branding:** Agents must not prepend "AI-Generated" or similar
   self-crediting labels to commit messages unless explicitly configured by the
   architect for audit purposes.

---

## Section 4 — What Agents Can and Cannot Do (Security Invariants)

| Agent | Can | Cannot |
|-------|-----|--------|
| Gemini CLI | Peer developer. Propose, review, derive, and implement. | Write to src/ without task in projecttracking.md |
| Claude Code | Peer developer. Propose, review, derive, and implement. | See the other agent's reasoning before producing its own |
| Codex | Peer developer and tiebreaker. | Bypass governance gates |

### Core Security Invariants (v1.1)

**Runtime UX Guardrails (User-Facing Non-Negotiables):**

- **No Raw JSON to Humans:** Any user-facing response in interactive flows MUST be plain language. Raw JSON objects, fenced JSON blocks, or internal schema payloads MUST NEVER be rendered directly to the user.
- **No Silent Shell Drop:** Interactive workflows (especially onboarding/setup) MUST NOT return the user to the shell without an explicit completion/failure summary and a recommended next action.

1. **Invariant 1:** No unapproved file modifications.
2. **Invariant 2:** No write access outside project root.
3. **Invariant 3:** No execution without human approval.
4. **Invariant 4:** Every operation reproducible from the event store.
5. **Invariant 5:** Failed builds revert automatically.
6. **Invariant 6:** No model bypasses `callModel`.
7. **Invariant 7:** Context isolation enforced at runtime.
8. **Invariant 8:** Secrets never enter sandbox execution.
9. **Invariant 9:** Local models stay local.
14. **Invariant 14:** No `write_file` for overwrites. Overwriting or modifying an existing
    file via `write_file` is prohibited. `replace` MUST be used for all modifications to
    existing files to ensure surgical precision. `write_file` is reserved for creating
    new files only.
18. **Invariant 18 (DB Write Prohibition):** Agents MUST NOT write directly to any
    database (mirrorbox.db, dev-graph.db, or any SQLite file) under any circumstances.
    The `tasks` table and all pipeline state in the DB is seeded exclusively by the
    Operator running the pipeline from `projecttracking.md`. Agents interact with state
    only through governance files (`projecttracking.md`, `BUGS.md`, `.mbo/sessions/NEXT_SESSION.md`).
    Direct `INSERT`, `UPDATE`, or `DELETE` against any DB — via node eval, sqlite3 CLI,
    or any MCP tool call that proxies raw SQL — is a governance violation equivalent to
    bypassing the handshake protocol.

---

## Section 5 — Session Management & Two-World Integrity

### Invariant 10 (Two-World Isolation)
- Every operation shall explicitly declare its target scope: `world_id = mirror | subject`.
- Reads may span worlds; writes must target exactly one world.
- Missing or invalid `world_id` is a hard failure.

### Invariant 11 (Graph Investigation)
- Retrieval must use `graph_search` and `graph_query_impact`.
- Full SPEC/file-dump context injection is disallowed by default.

### Invariant 12 (HardState Budget)
- Enforce 5,000-token HardState ceiling.
- Allocation: 600 invariants, 1,800 evidence, 1,200 prior decisions, 900 reasoning,
  500 reserve.

### Invariant 13 (Pre-Mutation Checkpoints & Backups)
- Immutable checkpoint required before any mutation in either world.
- **Atomic Topology Backup:** Before any file modification or creation, a backup of
  the original document MUST be written to `.dev/bak/` preserving the same directory
  topology as the repository.

### Invariant 15 (Non-Destructive Recovery)
- Prohibit `rm -f` and delete/recreate schema recovery patterns.

### Invariant 16 (Atomic Session-End Backup)
- On session close, atomically persist event flush, graph delta, handoff record, and
  integrity hashes.
- Run `PRAGMA integrity_check`.

### Invariant 17 (Worktree-Isolated Verification Gate)
- All implementation work MUST occur in a dedicated git worktree with its own branch
  (`<agent>/<task-or-scope>`, e.g. `claude/`, `gemini/`, `codex/`).
- Worktree path convention: `.dev/worktree/<agent>-<task>/`
  (for example, `.dev/worktree/codex-v0.11.86/`)
- Create with: `git worktree add .dev/worktree/<agent>-<task> -b <agent>/<task>`
- Each agent session MUST use its own worktree. Sharing a working directory between
  concurrent agents is prohibited.
- No apply/merge/promotion to the target branch until verification gate passes.

- Verification gate minimum: `python3 bin/validator.py --all` passes, task-specific
  tests pass, and no new P0/P1 regressions are introduced.
- If verification fails, fix-forward on the same working branch; do not apply partial
  changes.
- On session close, remove the worktree after branch finalization.

---

## Section 6 — Proactive State Sync & Session Protocols

### 6A. The Audit Gate (Completion Trigger)
The moment a task is implemented and Stage 8 passes, halt and present the audit package:
1. Unified diff of all changes.
2. Full output of `python3 bin/validator.py --all`.
3. One-paragraph summary.

### 6B. State Sync (Automatic on Approval)
On `approved`: update `projecttracking.md` and `BUGS.md`
as defined by the active task.

### 6C. Session End
If "end session" is requested:
1. Terminate MCP.
2. Run Branch Finalization.
3. Output checklist.


### 6D. Branch Finalization (Required Before Session Close)
1. If verification gate passed and changes are approved, promote branch changes to
   target branch via approved merge strategy.
2. Record promotion outcome in session artifacts (audit gate output plus state-sync files).
3. Remove the working branch after successful promotion (local + remote) unless
   explicitly marked for retention.
4. Retained branches MUST be renamed or created under `archive/` with a short reason
   in session handoff.

---

## Section 7 — Critical Constraints

1. `callModel` is the only path to any model.
2. No file write outside approved scope.
3. No code touches a real repository without human `go`.
4. Every model call logged to event store before and after.
5. Reviewer never sees planner output before Stage 4C.

---

## Section 8 — Required Affirmation

Before this session proceeds, you must physically read the governance files and report
the base nhash:
`(AGENTS sections + BUGS sections) × 3 = [Base Result]`

Wait for human salt. Calculate `nhash * salt = Hard State Anchor`.

**Non-Persistence Mandate:** You MUST NOT document, persist, or commit the nhash
calculation, the salt, or the resulting Anchor in any file. This value exists only
within the `[Hard State: X]` tag in internal reasoning blocks for the duration of the
current session.

Report the Hard State Anchor and state: "I will not make assumptions about the
intentions of the human at any time."

Identify the next scheduled task from `projecttracking.md` and ask: "Would you like to
work on this or something else?"

---

## Section 9 — Strict Mode (Code Output Constraints)

1. **Unified Diffs Only:** All modifications must be proposed as a unified diff.
2. **No stylistic or cleanup changes** unless they fix a functional bug or improve
   performance >10%.
3. **Handshake Protocol:**
   - `src/**`: Locked (444). Ask human for `mbo auth src`, wait for `go`, use
     `impl_step.sh`.
   - `.dev/governance/**`, `scripts/**`, `bin/**`: Unlocked. Use `impl_step.sh`.

---

## Section 10 — Hard State Persistence

Explicitly state your **Hard State Anchor** at the beginning of every internal
`<thinking>` block: `<thinking>[Hard State: X] ...`

**No File Modifications Without Explicit Approval:** Agents must NOT edit, create, or
modify any file without explicit human authorization ("go"). All file interactions must
use approved tooling.

---

## Section 11 — Graph-Assisted Context

Run only the queries listed in `projecttracking.md` or derived from the active task description.
Load only the files and SPEC sections those queries return.

**MCP connection:**
The graph server is a launchd-managed daemon at a project-scoped dynamic endpoint
(manifest-resolved).

If the dev graph server is unavailable:
- Check: `node scripts/mcp_query.js --diagnose graph_server_info`
- Start: `mbo setup`
- State: "Dev graph unavailable. Ran diagnostics — [result]. Awaiting human instruction."

MCP diagnostics command is canonical:
`node scripts/mcp_query.js --diagnose graph_server_info`

---

## Section 12 — MBO Operational Workflow (Sovereign Loop)

Every development session MUST follow this checklist:
1. **Identify Task** from `projecttracking.md`.
2. **Permission Check** via `python3 bin/handshake.py <cell_name>`.
3. **Create Working Worktree** — `git worktree add .dev/worktree/<agent>-<task>
   -b <agent>/<task>` — and work exclusively inside it.

   > **DB Write Prohibition:** At no point in this loop may an agent write directly to
   > mirrorbox.db or any pipeline database. All task state flows through governance
   > files → Operator → pipeline. (See Invariant 18.)
4. **Derive & Propose** solution from graph context.
5. **Human Approval** ("go").
6. **Implement & Verify** (`python3 bin/validator.py --all` + task-specific tests).
7. **Verification Gate Decision** — promotion is allowed only after required checks pass.
8. **Audit Gate** (diff + validator output + summary).
9. **Sync State** (`projecttracking.md`, `BUGS.md`).
10. **Branch Finalization** (promote approved, verified branch to target, then delete
    or archive branch).
11. **Lock & Journal** (`handshake.py --revoke` and `init_state.py`).

---

## Section 13 — Persona Store & Reasoning Constraints

### 13A. Persona Resolution
Agents derive their reasoning style from Persona Markdown files. The system resolves
these in order:
1. `~/.orchestrator/personas/<id>.md` (User library)
2. `<project>/.mbo/personalities/<id>.md` (Project overrides)
3. `<MBO_ROOT>/personalities/<alias>.md` (System defaults)

### 13B. Reasoning Constraints
Personas are not cosmetic. Each persona defines a **Reasoning Constraint** based on
the role's primary failure mode:
- **Classifier (The Sentry):** Structurally biased toward escalation; "When in doubt,
  escalate."
- **Planner (The Minimalist):** Every line must earn its place; anti-over-engineering.
- **Reviewer (The Skeptic):** Adversarial independence; derive first, then compare.
- **Tiebreaker (The Arbitrator):** Select, don't synthesize; rule on load-bearing diffs.
- **Operator (The Anchor):** Clarity under complexity; human-readable status only.

### 13C. Project Assignments (`.mbo/persona.json`)
Projects define their active personas in `.mbo/persona.json`. Changes to this file
travel with the repository.

---

## Section 14 — Entropy Gate & Decomposition

### 14A. Entropy Score Calculation
Every task in Stage 1.5 generates an **Entropy Score** via the Assumption Ledger:
- **Critical Assumption:** 3.0 points
- **High Impact Assumption:** 1.5 points
- **Low Impact Assumption:** 0.5 points

### 14B. The Hard Stop
- **Entropy > 10:** The task is **BLOCKED**. The pipeline halts before any planning
  begins.
- **Remedy:** The human Architect must decompose the task into smaller, independent
  subtasks until the entropy of each subtask is ≤ 10.

---

## Section 15 — Task Versioning Scheme

**Legacy format (pre-2026-03-16):** `<Milestone>-[Type]<TaskNum>`
Examples: `1.0-09`, `1.1-H37`, `1.1-ISS-04`

**New format (from 2026-03-16):** `v<Major>.<MilestoneNN>.<TaskNum>`
- **Major:** `0` (static, matches package.json major version)
- **MilestoneNN:** milestone number with dot removed (1.0 → `10`, 1.1 → `11`)
- **TaskNum:** zero-padded task sequence within the milestone

Examples: `v0.10.09`, `v0.11.37`, `v0.12.01`

**Migration policy:**
1. Completed tasks retain their legacy IDs unchanged (no retroactive renumbering).
2. Outstanding tasks at adoption time carry both IDs (e.g. `1.0-09 (v0.10.09)`).
3. All new tasks planned from 2026-03-16 onward use only the new format.

---

## Section 16 — Workflow Canonicalization (Single Source of Truth)

To eliminate state drift across governance files, workflow ownership is strict:

1. `projecttracking.md` is the only canonical task ledger.
2. Every active task row MUST include: Task ID, Type, Status, Owner, Branch, Updated,
   Links, Acceptance.
3. `BUGS.md` is a bug registry only. Every OPEN/PARTIAL P0/P1 bug MUST include a
   `Task:` link to a task ID in `projecttracking.md`.
4. `projecttracking.md` is the only source for session state.
5. Session-close script updates `projecttracking.md` with handoff context as needed.
6. Approved design decisions (DDR-001/002/003 and successors) require:
   - a task entry in `projecttracking.md`, and
   - normative promotion into `SPEC.md`.
7. Technical debt tracking is not a parallel governance ledger:
   - actionable verification items belong in `BUGS.md` with linked tasks,
   - `TECHNICAL_DEBT.md` is archived under `.dev/archive/`.
8. `python3 bin/validator.py --all` MUST fail when:
   - any OPEN/PARTIAL P0/P1 bug lacks a linked task ID,
   - linked task ID does not exist in `projecttracking.md`.


**Authoring rule:** update state only at task status transitions and at session close.

---

## Section 17 — Client Project Footprint Boundary

This document governs MBO development in the MBO repository.
In client projects, MBO-authored artifacts live under `.mbo/` only.
Client policy file `.mbo/AGENTS.md` is a generated artifact from the onboarding
profile and is not a copy of this document.
Nothing MBO-authored should be written to client project root by default.

---

*Last updated: 2026-03-18 — Governance collapse (COLLAPSE-01). C1–C6 resolved.
Invariant 17 → Worktree-Isolated. Invariant 18 → DB Write Prohibition.
Invariants 19/20 removed. Section 11 → mcp_query.js canonical.
Section 16 → DDR task/SPEC ownership and tech debt archive policy.
Section 17 added. NEXT_SESSION.md canonical path → .mbo/sessions/NEXT_SESSION.md.*
