# projecttracking.md
## Mirror Box Orchestrator — Build Tracking

**Current Milestone:** 1.1 — Portability & Tokenizer [IN PROGRESS]
**Next Action:** 1.1-05 — Implement launch sequence — version check, re-onboard trigger

---

## NEXT ACTION

**Task 1.1-05 — Implement launch sequence — version check, re-onboard trigger (Section 28.5)**

Goal: finalize and harden the authoritative boot order after 1.1-04 project init completion.

Scope for 1.1-05:
1. Root resolution from invocation cwd with `.mbo` upward walk.
2. Config validation + corrupt rename handling.
3. Provider heartbeat gate with explicit failure messaging.
4. Project init invoke order and idempotency guarantee.
5. Onboarding version mismatch re-onboard trigger with prior defaults.
6. Non-TTY hard-fail behavior (no interactive prompt).

Required validation for close:
- clean startup from external project folder
- refusal to run from controller folder
- no port/process hijack behavior
- deterministic error for missing providers
- deterministic error for non-TTY missing config

---

## MILESTONE 1.1 — Portability & Tokenizer [IN PROGRESS]
| Task ID | Task Description | Status |
|---------|------------------|--------|
| 1.1-01 | Fix BUG-051: DBManager DB path resolution (Section 28.8) | COMPLETED |
| 1.1-02 | Fix BUG-052: Create bin/mbo.js launcher + package.json bin entries (Section 28.1) | COMPLETED |
| 1.1-03 | Implement mbo setup wizard — ~/.mbo/config.json, provider detection (Section 28.6) | COMPLETED |
| 1.1-04 | Implement .mbo/ project init — directory walk, .gitignore guard (Section 28.3) | COMPLETED |
| 1.1-05 | Implement launch sequence — version check, re-onboard trigger (Section 28.5) | OPEN |
| 1.1-06 | Fix BUG-050: Validator failure halts pipeline, re-enters Stage 3A (Section 28) | OPEN |
| 1.1-07 | Implement Tokenizer module — scan, onboard, track (Section 29) | OPEN |
| 1.1-08 | Implement token accounting — event schema, live tally, session summary (Section 30) | OPEN |
| 1.1-09 | Wire Tokenizer into MBO launch sequence as onboarding engine | OPEN |

---

## MILESTONE 1.1 — Hardening (Executable Scope) [IN PROGRESS]
| Task ID | Task Description | Status |
|---------|------------------|--------|
| 1.1-H01 | Implement Project Root Resolution (walking up for .mbo/) | COMPLETED |
| 1.1-H02 | Implement Machine Config validation & corrupt-rename logic | COMPLETED |
| 1.1-H03 | Implement Non-TTY Guard & Env-Var output for CI | COMPLETED |
| 1.1-H04 | Implement .mbo/ Scaffolding and .gitignore Automator | COMPLETED |
| 1.1-H05 | Implement Authoritative Launch Sequence (Step 1-7) | IN REVIEW |
| 1.1-H06 | Implement Tokenizer Baseline & Current-Raw scan hooks | OPEN |
| 1.1-H07 | Implement TOKEN_USAGE event emission in call-model.js | OPEN |
