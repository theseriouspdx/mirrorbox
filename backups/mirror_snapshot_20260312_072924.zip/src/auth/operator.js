const { spawn, execSync, spawnSync } = require('child_process');
const http = require('http');
const fs = require('fs');
const path = require('path');
const { callModel, computeContentHashes } = require('./call-model');
const stateManager = require('../state/state-manager');
const db = require('../state/db-manager');
const eventStore = require('../state/event-store');

const MBO_ROOT = path.resolve(__dirname, '../..');

const {
  resolveManifest,
  readManifest,
  getRunDir: _getRunDir,
  tryReadManifestRelaxed,
} = require('../utils/resolve-manifest');

// Mode-aware run dir — used everywhere PID/session files are written.
function getRunDir(mode) {
  return _getRunDir(mode || 'runtime');
}

function readProcessStartMs(pid) {
  try {
    const out = execSync(`ps -o lstart= -p ${pid}`, { encoding: 'utf8' }).trim();
    if (!out) return null;
    const ms = Date.parse(out);
    return Number.isFinite(ms) ? Math.floor(ms / 1000) * 1000 : null;
  } catch {
    return null;
  }
}

function readProcessCommand(pid) {
  try {
    return execSync(`ps -o command= -p ${pid}`, { encoding: 'utf8' }).trim();
  } catch {
    return null;
  }
}

function getExpectedProjectRoot() {
  return fs.realpathSync(process.env.MBO_PROJECT_ROOT || process.cwd());
}

/**
 * Section 8: The Operator
 * The persistent session anchor. Classification, routing, and context management.
 */
class Operator {
  // Context window sizes by model (tokens). Used when config doesn't specify.
  static CONTEXT_WINDOWS = {
    'claude-opus-4':           200000,
    'claude-3.7-sonnet':       200000,
    'claude-3.5-sonnet':       200000,
    'gemini-2.0-pro':          1000000,
    'gemini-pro-1.5':          1000000,
    'gpt-4o':                  128000,
    'qwen2.5-coder-7b':        32768,
    'deepseek-coder-v2':       32768,
    'ollama':                  4096,   // conservative fallback for unknown local models
    'default':                 32000,
  };

  constructor(mode = 'runtime') {
    this.mode = mode;
    this.sessionHistory = [];
    this.stateSummary = {
      worldId: 'mirror',
      currentTask: null,
      currentStage: 'classification',
      activeModel: 'operator',
      filesInScope: [],
      recoveryAttempts: 0,
      blockCounter: 0,
      progressSummary: '',
      graphSummary: '',
      pendingDecision: null
    };
    this.mcpServer = null;
    this.mcpSessionId = null;
    this.mcpPort = null;
    this.messageId = 1;
    this.contextThreshold = 0.8;      // Section 8: configurable via operatorContextThreshold
    this.activeModelWindow = null;    // set after routeModels() resolves, see _loadModelWindow()
    this.sandboxFocus = false;        // BUG-013: Sandbox interaction state
    this.mcpRestartHistory = [];
    this.mcpCircuitThreshold = 3;
    this.mcpCircuitWindowMs = 30000;
  }

  _registerMCPRestartFailure(reason = 'unknown') {
    const now = Date.now();
    this.mcpRestartHistory = this.mcpRestartHistory
      .filter((entry) => now - entry.ts <= this.mcpCircuitWindowMs);
    this.mcpRestartHistory.push({ ts: now, reason });

    if (this.mcpRestartHistory.length >= this.mcpCircuitThreshold) {
      const incident = {
        status: 'incident',
        incident_reason: `circuit_breaker_open: ${this.mcpRestartHistory.length} restart failures within ${Math.floor(this.mcpCircuitWindowMs / 1000)}s`,
      };
      try {
        const manifestPath = getManifestPath();
        const current = readManifest() || {};
        const payload = {
          ...current,
          status: incident.status,
          incident_reason: incident.incident_reason,
          restart_count: this.mcpRestartHistory.length,
          last_verified_at: new Date().toISOString(),
        };
        if (payload.checksum) {
          const { checksum, ...withoutChecksum } = payload;
          payload.checksum = computeManifestChecksum(withoutChecksum);
        }
        writeManifestAtomic(manifestPath, payload);
      } catch (_) {}
      throw new Error(`[Operator] MCP incident: ${incident.incident_reason}`);
    }
  }

  _validateManifestV3(manifest) {
    if (!manifest || typeof manifest !== 'object') {
      throw new Error('[Operator] MCP manifest missing or invalid JSON.');
    }

    const required = [
      'manifest_version', 'checksum', 'project_root', 'project_id', 'pid', 'process_start_ms',
      'port', 'mode', 'epoch', 'instance_id', 'started_at', 'last_verified_at', 'status',
      'restart_count', 'incident_reason'
    ];

    for (const key of required) {
      if (!(key in manifest)) {
        throw new Error(`[Operator] MCP manifest missing required field: ${key}`);
      }
    }

    if (manifest.manifest_version !== 3) {
      throw new Error(`[Operator] MCP manifest version mismatch. Expected 3, got ${manifest.manifest_version}`);
    }

    if (typeof manifest.instance_id !== 'string' || manifest.instance_id.length < 8) {
      throw new Error('[Operator] MCP manifest has invalid instance_id.');
    }

    if (!Number.isInteger(Number(manifest.epoch)) || Number(manifest.epoch) < 1) {
      throw new Error('[Operator] MCP manifest has invalid epoch.');
    }

    const { checksum, ...withoutChecksum } = manifest;
    const computed = computeManifestChecksum(withoutChecksum);
    if (checksum !== computed) {
      throw new Error('[Operator] MCP manifest checksum mismatch.');
    }

    if (manifest.status !== 'ready') {
      throw new Error(`[Operator] MCP manifest status is "${manifest.status}" — server not ready. incident_reason: ${manifest.incident_reason || 'none'}`);
    }

    const expectedRoot = getExpectedProjectRoot();
    if (manifest.project_root !== expectedRoot) {
      throw new Error(`[Operator] MCP project_root mismatch. expected=${expectedRoot} got=${manifest.project_root}`);
    }

    if (!Number.isInteger(Number(manifest.restart_count)) || Number(manifest.restart_count) < 0) {
      throw new Error('[Operator] MCP manifest has invalid restart_count.');
    }

    const startMs = readProcessStartMs(Number(manifest.pid));
    const manifestStartMs = Math.floor(Number(manifest.process_start_ms) / 1000) * 1000;
    if (!startMs || startMs !== manifestStartMs) {
      throw new Error('[Operator] MCP process fingerprint mismatch (pid/start time).');
    }

    const cmd = readProcessCommand(Number(manifest.pid));
    if (!cmd || !cmd.includes('mcp-server.js') || !cmd.includes(expectedRoot)) {
      throw new Error('[Operator] MCP process fingerprint mismatch (command/root).');
    }

    return manifest;
  }

  /**
   * BUG-013: Toggles focus between the MBO CLI and the active sandbox.
   */
  toggleSandboxFocus() {
    this.sandboxFocus = !this.sandboxFocus;
    return this.sandboxFocus;
  }

  /**
   * Reads the operator's model window size from routing config.
   * Falls back to a conservative 32k if the model is unknown.
   * Called once after MCP start when providers are known.
   */
  async _loadModelWindow() {
    try {
      const { routingMap } = await (require('./model-router').routeModels());
      const operatorConfig = routingMap['classifier'] || routingMap['architecturePlanner'];
      if (operatorConfig) {
        const modelName = operatorConfig.model || 'default';
        this.activeModelWindow =
          Operator.CONTEXT_WINDOWS[modelName] ||
          Operator.CONTEXT_WINDOWS['default'];
      } else {
        this.activeModelWindow = Operator.CONTEXT_WINDOWS['default'];
      }
    } catch {
      this.activeModelWindow = Operator.CONTEXT_WINDOWS['default'];
    }
    console.error(`[Operator] Context window set to ${this.activeModelWindow} tokens (threshold: ${Math.floor(this.activeModelWindow * this.contextThreshold)})`);
  }

  /**
   * Section 9: Gate 0 - Initialize MCP session
   */
  async startMCP() {
    const scriptPath = path.join(__dirname, '../../scripts/mbo-start.sh');
    const args = this.mode === 'dev' ? ['--mode=dev'] : [];
    const manifest = readManifest();
    if (manifest) {
      try {
        this._validateManifestV3(manifest);
      } catch (err) {
        console.error(`[Operator] Existing MCP manifest invalid: ${err.message}. Attempting scoped restart path.`);
      }
    }
    // Use port from manifest only if it passed validation — don't carry over a stale port.
    this.mcpPort = (manifest && manifest.status === 'ready' && Number.isFinite(Number(manifest.port)))
      ? Number(manifest.port)
      : null;
    
    const portBusy = this.mcpPort ? await this._isPortBound(this.mcpPort) : false;

    if (!portBusy) {
      // Port is free — spawn the MCP server process.
      try {
        await this._spawnMCPServer(scriptPath, args);
        await this._waitForMCPReady();
        // Re-read manifest after server is up to get the actual live port.
        const liveManifest = readManifest({ mustReady: false });
        if (liveManifest && Number.isFinite(liveManifest.port)) {
          this.mcpPort = liveManifest.port;
        }
      } catch (err) {
        this._registerMCPRestartFailure(err.message);
        throw err;
      }
    } else {
      console.error(`[Operator] MCP port ${this.mcpPort} already bound — reusing existing server.`);
      // Restore persisted session ID so subsequent requests carry the correct header.
      const sessionFile = path.join(getRunDir(this.mode), 'mcp.session');
      try {
        const saved = require('fs').readFileSync(sessionFile, 'utf8').trim();
        if (saved) {
          this.mcpSessionId = saved;
          console.error(`[Operator] Restored MCP session ID from disk: ${saved}`);
        }
      } catch (_) {
        // No persisted session — server will reject non-initialize requests;
        // _initializeMCPWithRetry will handle the fallback.
      }
    }

    try {
      await this._initializeMCPWithRetry(portBusy);
    } catch (err) {
      this._registerMCPRestartFailure(err.message);
      throw err;
    }

    // Task 1.1-10: Assert the server is serving the correct project root.
    // Hard fails with an actionable message if project_id mismatches.
    const serverInfo = await this._assertProjectId();
    if (serverInfo.is_scanning) {
      await this._waitForScanComplete();
    }

    if (this.mode === 'dev') {
      await this._ensureDevGraphFreshOrRecover(scriptPath, args);
    }

    // Best-effort initialization notification; server compatibility may vary.
    await this.sendMCPNotification('notifications/initialized', {});
    await this._loadModelWindow();
  }

  async _spawnMCPServer(scriptPath, args) {
    const logDir = path.join(__dirname, '../../.dev/logs');
    const logPath = path.join(logDir, 'mcp-stderr.log');
    let logFd;
    try {
      require('fs').mkdirSync(logDir, { recursive: true });
      logFd = require('fs').openSync(logPath, 'a');
    } catch (e) {
      console.error(`[Operator] WARN: Could not open MCP log file: ${e.message}`);
    }

    this.mcpServer = spawn(scriptPath, args, {
      stdio: ['ignore', 'ignore', logFd || 'inherit'],
      env: { ...process.env, NODE_ENV: this.mode === 'dev' ? 'development' : 'production' },
      detached: false,
    });

    if (logFd) {
      this.mcpServer.on('spawn', () => require('fs').closeSync(logFd));
    }

    this.mcpServer.on('exit', (code, signal) => {
      if (code !== 0 && code !== null) {
        console.error(`[Operator] MCP launcher exited with code=${code} signal=${signal || 'none'}.`);
      }
    });
  }

  async _killServerOnPort(port) {
    try {
      const out = execSync(`lsof -ti:${port}`, { encoding: 'utf8' }).trim();
      if (!out) return;
      for (const pidStr of out.split(/\s+/)) {
        const pid = parseInt(pidStr, 10);
        if (Number.isFinite(pid)) {
          try { process.kill(pid, 'SIGTERM'); } catch (_) {}
        }
      }
      await new Promise(r => setTimeout(r, 500));
    } catch (_) {
      // nothing listening or lsof unavailable
    }
  }

  async _restartMCPServer(scriptPath, args) {
    console.error(`[Operator] Restarting MCP server on port ${this.mcpPort} for self-healing...`);

    if (this.mcpServer) {
      try { this.mcpServer.kill('SIGTERM'); } catch (_) {}
      this.mcpServer = null;
    }
    await this._killServerOnPort(this.mcpPort);

    const sessionFile = path.join(getRunDir(this.mode), 'mcp.session');
    try { require('fs').unlinkSync(sessionFile); } catch (_) {}
    this.mcpSessionId = null;

    await this._spawnMCPServer(scriptPath, args);
    await this._waitForMCPReady();
    await this._initializeMCPWithRetry(false);
    const info = await this._assertProjectId();
    if (info.is_scanning) {
      await this._waitForScanComplete();
    }
  }

  async _ensureDevGraphFreshOrRecover(scriptPath, args) {
    const epoch = new Date(0).toISOString();
    const isHealthy = (serverInfo, summary) => {
      const status = String(
        (serverInfo && serverInfo.last_scan_status) ||
        (summary && summary.status) ||
        'unknown'
      ).toLowerCase();
      const criticalFailures = Number(
        (serverInfo && serverInfo.last_scan_critical_failures) ??
        (summary && summary.critical_failures) ??
        1
      );
      return (status === 'completed' || status === 'completed_with_warnings') && criticalFailures === 0;
    };

    const tryRescan = async () => {
      const beforeInfo = await this.callMCPTool('graph_server_info', {});
      const before = JSON.parse(beforeInfo.content[0].text);
      const revBefore = Number(before.index_revision || 0);

      const rescanResult = await this.callMCPTool('graph_rescan', {});
      let summary = null;
      try {
        summary = JSON.parse(rescanResult.content[0].text);
      } catch (_) {
        // keep going, rev check is authoritative
      }

      const afterInfo = await this.callMCPTool('graph_server_info', {});
      const after = JSON.parse(afterInfo.content[0].text);
      const revAfter = Number(after.index_revision || 0);
      const freshTimestamp = after.last_indexed_at && after.last_indexed_at !== epoch;
      const healthy = isHealthy(after, summary);

      return {
        ok: revAfter > revBefore && freshTimestamp && healthy,
        revBefore,
        revAfter,
        lastIndexedAt: after.last_indexed_at,
        lastScanStatus: after.last_scan_status,
        lastScanCriticalFailures: after.last_scan_critical_failures,
        summary,
      };
    };

    try {
      const first = await tryRescan();
      if (first.ok) return;
      console.error(`[Operator] Dev graph freshness check failed (rev ${first.revBefore} -> ${first.revAfter}, ts=${first.lastIndexedAt}, status=${first.lastScanStatus}, critical=${first.lastScanCriticalFailures}). Attempting self-heal restart.`);
    } catch (e) {
      console.error(`[Operator] Dev graph rescan failed (${e.message}). Attempting self-heal restart.`);
    }

    await this._restartMCPServer(scriptPath, args);
    const second = await tryRescan();
    if (!second.ok) {
      throw new Error(
        `[Operator] Dev graph still stale/unhealthy after self-heal restart (rev ${second.revBefore} -> ${second.revAfter}, ts=${second.lastIndexedAt}, status=${second.lastScanStatus}, critical=${second.lastScanCriticalFailures}).`
      );
    }
  }

  /**
   * Returns true if something is already listening on this.mcpPort.
   * Uses a non-blocking TCP probe — no child process required.
   */
  _isPortBound(port) {
    return new Promise((resolve) => {
      const net = require('net');
      const sock = net.createConnection(port, '127.0.0.1');
      sock.once('connect', () => { sock.destroy(); resolve(true); });
      sock.once('error', () => resolve(false));
    });
  }

  /**
   * Waits for the sentinel file written by mcp-server.js on successful bind,
   * OR falls back to TCP polling if the sentinel does not appear in time.
   * Timeout: 15 seconds total.
   */
  async _waitForMCPReady(timeoutMs = 15000) {
    const sessionFile = path.join(getRunDir(this.mode), 'mcp.ready');
    const interval = 100;
    const deadline = Date.now() + timeoutMs;

    // Remove any stale sentinel from a previous run before waiting.
    try { require('fs').unlinkSync(sentinelPath); } catch (_) {}

    while (Date.now() < deadline) {
      if (require('fs').existsSync(sessionFile)) return;
      if (!this.mcpPort) {
        const m = tryReadManifestRelaxed(path.join(getRunDir(this.mode), 'mcp.json'))
               || tryReadManifestRelaxed(path.join(getRunDir('runtime'), 'mcp.json'));
        if (m && Number.isFinite(m.port)) this.mcpPort = m.port;
      }
      // Fallback: TCP probe (handles cases where sentinel write fails).
      if (this.mcpPort && await this._isPortBound(this.mcpPort)) return;
      await new Promise(r => setTimeout(r, interval));
    }
    throw new Error(`MCP server did not become ready on port ${this.mcpPort} within ${timeoutMs}ms. Check .dev/logs/mcp-stderr.log`);
  }

  /**
   * Sends the MCP initialize handshake.
   *
   * When portBusy=true the server already has an active session from a prior
   * Operator instance. In that case we skip initialize entirely — the session
   * ID is unknown and re-initializing would return "Server already initialized".
   * Instead we do a lightweight tools/list probe to confirm the server is live.
   *
   * When portBusy=false we just spawned the server so we own the fresh session.
   */
  async _initializeMCPWithRetry(portBusy = false) {
    if (portBusy) {
      // Server already running — probe with tools/list instead of initialize.
      try {
        await this.sendMCPRequest('tools/list', {});
        console.error(`[Operator] Reused existing MCP session on port ${this.mcpPort}.`);
        return;
      } catch (err) {
        // If we had a restored session ID, the server may have restarted
        // (new session assigned). Evict the stale session file and fall through
        // to re-initialize with a clean slate.
        if (this.mcpSessionId) {
          console.error(`[Operator] Stored session ID rejected (${err.message}) — server likely restarted. Re-initializing.`);
      const sessionFile = path.join(getRunDir(this.mode), 'mcp.session');
      try { require('fs').unlinkSync(sessionFile); } catch (_) {}
      this.mcpSessionId = null;
      } else {
          // No stored session — server may enforce session on all endpoints.
          console.error(`[Operator] tools/list probe failed with no stored session (${err.message}). Attempting initialize.`);
        }
      }
    }

    const maxAttempts = 10;
    let lastError = null;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        const res = await this.sendMCPRequest('initialize', {
          protocolVersion: '2024-11-05',
          capabilities: {},
          clientInfo: { name: 'mbo-operator', version: '1.0.0' }
        });
        if (res !== null) return; // Normal success path.
      } catch (err) {
        if (err.message && err.message.includes('Server already initialized')) {
          // Harmless race: server was already initialized (e.g. another client beat us).
          // Session ID was captured from the response header — we can proceed.
          console.error(`[Operator] MCP already initialized — session captured, proceeding.`);
          return;
        }
        lastError = err;
        await new Promise((resolve) => setTimeout(resolve, 300 * attempt)); // backoff
      }
    }

    throw new Error(`MCP initialize failed on port ${this.mcpPort || 'unknown'}: ${lastError ? lastError.message : 'unknown error'}`);
  }

  async sendMCPNotification(method, params) {
    try {
      await this._sendMCPHttp({
        jsonrpc: '2.0',
        method,
        params
      });
    } catch {
      // Notification is optional for current server behavior.
    }
  }

  /**
   * Task 1.1-10: Assert the graph server is serving the correct project root.
   * Computes project_id from MBO_ROOT using the same UTF-8 sha256 contract as the server.
   * Hard fails with an actionable error message on mismatch.
   */
  async _assertProjectId() {
    const result = await this.callMCPTool('graph_server_info', {});
    const info = JSON.parse(result.content[0].text);

    const { createHash } = require('crypto');
    const expectedRoot = getExpectedProjectRoot();
    // UTF-8 encoding matches mcp-server.js — part of the trust contract, do not change.
    const expectedId = createHash('sha256')
      .update(Buffer.from(expectedRoot, 'utf8'))
      .digest('hex')
      .slice(0, 16);

    if (info.project_id !== expectedId) {
      throw new Error(
        `[Operator] FATAL: Graph server project_id mismatch.\n` +
        `  Expected: ${expectedId} (root: ${expectedRoot})\n` +
        `  Got:      ${info.project_id} (root: ${info.project_root})\n` +
        `  The server is serving a different project.\n` +
        `  Kill and restart MCP: lsof -ti:${this.mcpPort} | xargs kill -9`
      );
    }

    console.error(`[Operator] Graph server identity verified: project_id=${info.project_id}, index_revision=${info.index_revision}`);
    return info;
  }

  /**
   * Task 1.1-10: Wait for an in-progress graph scan to complete.
   * Bounded to 6 attempts × 5s = 30s max. Not an open loop — each poll is a full
   * MCP tool call, so interval spacing matters.
   */
  async _waitForScanComplete(maxAttempts = 6, intervalMs = 5000) {
    for (let i = 0; i < maxAttempts; i++) {
      const result = await this.callMCPTool('graph_server_info', {});
      const info = JSON.parse(result.content[0].text);
      if (!info.is_scanning) return info;
      console.error(`[Operator] Graph scan in progress (${i + 1}/${maxAttempts}), waiting ${intervalMs}ms...`);
      await new Promise(r => setTimeout(r, intervalMs));
    }
    throw new Error(`[Operator] Graph server still scanning after ${maxAttempts * intervalMs / 1000}s. Aborting.`);
  }

  sendMCPRequest(method, params) {
    const id = this.messageId++;
    return this._sendMCPHttp({
      jsonrpc: '2.0',
      id,
      method,
      params
    });
  }

  _sendMCPHttp(payload) {
    return new Promise((resolve, reject) => {
      if (!this.mcpPort) {
        const m = tryReadManifestRelaxed(path.join(getRunDir(this.mode), 'mcp.json'))
               || tryReadManifestRelaxed(path.join(getRunDir('runtime'), 'mcp.json'));
        if (m && Number.isFinite(m.port)) this.mcpPort = m.port;
      }
      if (!this.mcpPort) return reject(new Error('MCP port not set'));

      const body = JSON.stringify(payload);
      const headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json, text/event-stream',
        'Content-Length': Buffer.byteLength(body),
      };
      if (this.mcpSessionId) {
        headers['mcp-session-id'] = this.mcpSessionId;
      }

      const req = http.request({
        host: '127.0.0.1',
        port: this.mcpPort,
        path: '/mcp',
        method: 'POST',
        headers,
      }, (res) => {
        const sid = res.headers['mcp-session-id'];
        if (sid) {
          this.mcpSessionId = Array.isArray(sid) ? sid[0] : sid;
          // Persist so a restarted Operator can rejoin an existing session.
          try {
            const runDir = getRunDir(this.mode);
            require('fs').mkdirSync(runDir, { recursive: true });
            require('fs').writeFileSync(path.join(runDir, 'mcp.session'), this.mcpSessionId, 'utf8');
          } catch (_) {}
        }

        const contentType = String(res.headers['content-type'] || '').toLowerCase();
        let responseBody = '';
        res.on('data', (chunk) => { responseBody += chunk.toString(); });
        res.on('end', () => {
          if (res.statusCode && res.statusCode >= 400) {
            return reject(new Error(`MCP HTTP ${res.statusCode}: ${responseBody || 'no response body'}`));
          }

          if (!responseBody.trim()) {
            return resolve(null);
          }

          const parseAndResolve = (jsonText) => {
            const msg = JSON.parse(jsonText);
            if (msg && msg.error) {
              reject(new Error(msg.error.message || JSON.stringify(msg.error)));
              return true;
            }
            resolve(msg.result);
            return true;
          };

          try {
            if (contentType.includes('text/event-stream')) {
              // Parse first JSON-RPC payload from SSE frames.
              const lines = responseBody.split(/\r?\n/);
              for (const line of lines) {
                if (!line.startsWith('data:')) continue;
                const data = line.slice(5).trim();
                if (!data || data === '[DONE]') continue;
                try {
                  if (parseAndResolve(data)) return;
                } catch (_) {
                  // ignore non-JSON SSE payloads (comments, pings, etc.)
                }
              }
              return reject(new Error(`Invalid MCP SSE response: ${responseBody.slice(0, 300)}`));
            }
            parseAndResolve(responseBody);
          } catch (e) {
            reject(new Error(`Invalid MCP JSON response: ${e.message}`));
          }
        });
      });

      req.setTimeout(15000, () => {
        req.destroy(new Error(`MCP request timeout for ${payload.method || 'notification'}`));
      });

      req.on('error', reject);
      req.write(body);
      req.end();
    });
  }

  async callMCPTool(name, args) {
    const result = await this.sendMCPRequest('tools/call', { name, arguments: args });
    return result;
  }

  _safeParseJSON(text, fallback = null) {
    if (!text) return fallback;
    try {
      const jsonMatch = text.match(/\{[\s\S]*\}/);
      return JSON.parse(jsonMatch ? jsonMatch[0] : text);
    } catch (e) {
      console.error(`[Operator] JSON Parse Failure: ${e.message}. Raw text: ${text.slice(0, 200)}...`);
      return fallback;
    }
  }

  /**
   * Section 8: Classification
   * Parses user message into a Classification object.
   */
  async classifyRequest(userMessage) {
    const hardState = this.getHardState();
    
    // Stage 1: Call Classifier model
    const input = {
      userMessage,
      sessionHistory: this.sessionHistory,
      stateSummary: this.stateSummary,
    };

    const prompt = `Classify this user request into a JSON object following this schema:
{
  "route": "inline" | "analysis" | "standard" | "complex",
  "worldId": "mirror" | "subject",
  "risk": "low" | "medium" | "high",
  "complexity": 1 | 2 | 3,
  "files": string[],
  "rationale": string,
  "confidence": number
}

User request: "${userMessage}"

Return ONLY the JSON object. Do not provide conversational filler.`;

    try {
      const response = await callModel('classifier', prompt, input, hardState);
      if (process.env.MBO_DEBUG) console.error(`[DEBUG] Classifier response: ${response}`);
      const classification = this._safeParseJSON(response);
      
      if (!classification || classification.confidence < 0.6) {
        return {
          needsClarification: true,
          rationale: classification ? classification.rationale : "Low confidence or parse failure.",
          confidence: classification ? classification.confidence : 0
        };
      }
      return classification;
    } catch (e) {
      console.error(`[Operator] Model classification failure: ${e.message}. Falling back to heuristic.`);
      return this._heuristicClassifier(userMessage);
    }
  }

  _heuristicClassifier(userMessage) {
    const files = userMessage.match(/[\w./-]+\.\w+/g) || [];
    let route = 'standard';
    let risk = 'low';
    let complexity = 1;
    
    if (userMessage.toLowerCase().includes('architectural') || userMessage.toLowerCase().includes('refactor')) {
      route = 'complex'; risk = 'high'; complexity = 3;
    } else if (files.length > 2) {
      route = 'standard'; risk = 'medium'; complexity = 2;
    } else if (userMessage.toLowerCase().includes('color') || userMessage.toLowerCase().includes('css')) {
      route = 'inline'; complexity = 1;
    }
    
    return {
      route,
      worldId: 'mirror',
      risk,
      complexity,
      files,
      rationale: "Heuristic classification (callModel fallback or placeholder).",
      confidence: 0.8,
      _source: 'heuristic' // internal tag for event logging
    };
  }

  /**
   * Section 8: Routing Tiers
   * Uses Intelligence Graph to determine Tier 0-3 based on blast radius.
   */
  async determineRouting(classification) {
    let tier = 1;
    let blastRadius = [];
    const worldId = classification.worldId || 'mirror';

    // Check Graph Completeness (Milestone 0.4A invariant)
    const graphCompleteness = this.getGraphCompleteness();
    if (graphCompleteness === 'skeleton') {
      return { tier: 1, blastRadius: [], rationale: 'Skeleton graph forces Tier 1 minimum.' };
    }

    if (classification.files && classification.files.length > 0) {
      for (const file of classification.files) {
        try {
          const impactResult = await this._graphQueryImpact(file, worldId);
          
          if (impactResult && impactResult.content && impactResult.content[0]) {
            const impact = JSON.parse(impactResult.content[0].text);
            if (impact && impact.affectedFiles) {
              blastRadius.push(...impact.affectedFiles);
            }
          }
        } catch (e) {
          console.error(`[Operator] Impact query failed for ${file}:`, e.message);
        }
      }
    }

    const uniqueBlast = [...new Set(blastRadius)];
    
    // Routing Matrix (Section 8)
    if (classification.route === 'complex' || classification.risk === 'high' || classification.complexity === 3) {
      tier = 3;
    } else if (uniqueBlast.length > 5 || classification.complexity === 2) {
      tier = 2;
    } else if (uniqueBlast.length === 0 && classification.complexity === 1 && classification.route === 'inline') {
      const safelist = this.getSafelist();
      const allSafelisted = classification.files.every(f => safelist.includes(f));
      const allExist = classification.files.every(f => this._fileExists(f));
      if (allSafelisted && allExist) {
        tier = 0;
      } else {
        console.error(`[Operator] Tier 0 denied: safelisted=${allSafelisted}, allExist=${allExist}. Routing Tier 1.`);
        tier = 1;
      }
    } else {
      tier = 1;
    }

    return { tier, blastRadius: uniqueBlast };
  }

  /**
   * §11 / 1.0-07: Route graph query to correct DB by world_id.
   * mirror → dev MCP (graph_query_impact via HTTP).
   * subject → direct DBManager query on subjectRoot/data/mirrorbox.db.
   */
  async _graphQueryImpact(file, worldId) {
    if (worldId === 'subject') {
      const profileRow = db.get('SELECT profile_data FROM onboarding_profiles ORDER BY version DESC LIMIT 1');
      if (!profileRow) return null;
      const { subjectRoot } = JSON.parse(profileRow.profile_data);
      if (!subjectRoot) return null;
      const subjectDbPath = path.join(subjectRoot, 'data/mirrorbox.db');
      const { DBManager } = require('../state/db-manager');
      const subjectDb = new DBManager(subjectDbPath);
      const nodeId = `file://${path.resolve(subjectRoot, file)}`;
      const rows = subjectDb.query(
        `SELECT target_id FROM edges WHERE source_id = ? AND relation = 'calls'`, [nodeId]
      );
      return { content: [{ text: JSON.stringify({ affectedFiles: rows.map(r => r.target_id) }) }] };
    }
    const nodeId = `file://${path.resolve(MBO_ROOT, file)}`;
    return this.callMCPTool('graph_query_impact', { nodeId });
  }

  getSafelist() {
    const profile = db.get('SELECT profile_data FROM onboarding_profiles ORDER BY version DESC LIMIT 1');
    if (!profile) return [];
    try { return JSON.parse(profile.profile_data).safelist || []; }
    catch { return []; }
  }

  _fileExists(filePath) {
    return fs.existsSync(path.resolve(MBO_ROOT, filePath));
  }

  /**
   * §12 Step 5: Implement & Validate
   * Grants write access, applies code to filesystem, runs validator.py.
   */
  async runStage6(code, files) {
    this.stateSummary.currentStage = 'implement';
    const modifiedFiles = [];

    for (const filePath of files) {
      const absPath = path.resolve(MBO_ROOT, filePath);
      const cellName = path.relative(path.join(MBO_ROOT, 'src'), absPath);

      // §12 Step 2: Permission check
      const hs = spawnSync('python3', [path.join(MBO_ROOT, 'bin/handshake.py'), cellName], { encoding: 'utf8' });
      if (hs.status !== 0) throw new Error(`[Stage6] Handshake denied for ${cellName}: ${hs.stderr}`);

      // Extract code block for this file (convention: fenced block tagged with filename)
      const blockRe = new RegExp(`\`\`\`[\\w.]*\\s*//\\s*${filePath.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}[\\s\\S]*?\`\`\``, 'g');
      const match = blockRe.exec(code);
      const fileContent = match
        ? match[0].replace(/^```[\w.]*\n/, '').replace(/\n```$/, '')
        : code;

      fs.mkdirSync(path.dirname(absPath), { recursive: true });
      fs.writeFileSync(absPath, fileContent, 'utf8');
      modifiedFiles.push(filePath);
      eventStore.append('FILE_WRITTEN', 'operator', { path: filePath }, 'mirror');
    }

    // §12 Step 5: Run validator
    const val = spawnSync('python3', [path.join(MBO_ROOT, 'bin/validator.py'), '--all'], { encoding: 'utf8' });
    const validatorOutput = val.stdout + val.stderr;
    const validatorPassed = val.status === 0;

    eventStore.append('VALIDATE', 'operator', { passed: validatorPassed, output: validatorOutput.slice(0, 500) }, 'mirror');

    return { modifiedFiles, validatorOutput, validatorPassed };
  }

  /**
   * §6A / §12 Step 5.5: Audit Gate
   * Presents diff + validator output + summary. Sets pendingAudit for REPL to resolve.
   */
  async runStage7(writeResult) {
    this.stateSummary.currentStage = 'audit_gate';

    let diff = '';
    try { diff = execSync('git diff HEAD', { cwd: MBO_ROOT, encoding: 'utf8' }); }
    catch (e) { diff = '[git diff unavailable]'; }

    const pkg = {
      diff,
      validatorOutput: writeResult.validatorOutput,
      summary: `Modified: ${writeResult.modifiedFiles.join(', ')}. Validator: ${writeResult.validatorPassed ? 'PASS' : 'FAIL'}.`
    };

    eventStore.append('AUDIT_PACKAGE', 'operator', { summary: pkg.summary, validatorPassed: writeResult.validatorPassed }, 'mirror');

    this.stateSummary.pendingAudit = pkg;
    // Approval is resolved by the REPL on 'approved'/'reject' input
    return { approved: false, pendingAuditPackage: pkg };
  }

  async runStage7Rollback(modifiedFiles) {
    try {
      execSync(`git checkout HEAD -- ${modifiedFiles.map(f => `"${f}"`).join(' ')}`, { cwd: MBO_ROOT });
      eventStore.append('ROLLBACK', 'operator', { files: modifiedFiles, reason: 'audit_rejected' }, 'mirror');
    } catch (e) {
      console.error(`[Stage7] Rollback failed: ${e.message}`);
    }
  }

  /**
   * §6B / §12 Steps 6-8: State Sync, Lock, Baseline
   */
  async runStage8(classification, routing) {
    this.stateSummary.currentStage = 'state_sync';

    // §12 Step 7: Lock src
    spawnSync('python3', [path.join(MBO_ROOT, 'bin/handshake.py'), '--revoke'], { encoding: 'utf8' });

    // §12 Step 8: Baseline
    const init = path.join(MBO_ROOT, 'bin/init_state.py');
    if (fs.existsSync(init)) spawnSync('python3', [init], { encoding: 'utf8' });

    eventStore.append('STATE_SYNCED', 'operator', { task: classification.files, tier: routing.tier }, 'mirror');
    this.stateSummary.currentStage = 'idle';
  }

  getPrimeDirective() {
    const profile = db.get('SELECT profile_data FROM onboarding_profiles ORDER BY version DESC LIMIT 1');
    return profile ? JSON.parse(profile.profile_data).primeDirective : "No prime directive set.";
  }

  /**
   * Section 13: Hard State
   * Immutable project context injected into every model call.
   */
  getHardState() {
    const profileRaw = db.get('SELECT profile_data FROM onboarding_profiles ORDER BY version DESC LIMIT 1');
    const profile = profileRaw ? JSON.parse(profileRaw.profile_data) : {};
    
    const hardState = {
      primeDirective: profile.primeDirective || "No prime directive set.",
      onboardingProfile: profile,
      graphSummary: this.stateSummary.graphSummary || "Intelligence Graph active. All subsystems mapped.",
      dangerZones: profile.dangerZones || []
    };

    // Budget check (5,000 tokens)
    const estimated = this._estimateTokens(hardState);
    if (estimated > 5000) {
      // Section 13 Truncation Priority:
      // 1. graphSummary (lowest priority)
      // 2. dangerZones
      // 3. onboardingProfile
      // 4. primeDirective (highest - never truncate)
      hardState.graphSummary = "[TRUNCATED]";
      if (this._estimateTokens(hardState) > 5000) {
        hardState.dangerZones = ["[TRUNCATED]"];
        if (this._estimateTokens(hardState) > 5000) {
          hardState.onboardingProfile = { primeDirective: hardState.primeDirective, _note: "Profile truncated due to budget" };
        }
      }
    }
    return hardState;
  }

  _estimateTokens(obj) {
    const str = typeof obj === 'string' ? obj : JSON.stringify(obj);
    return Math.ceil(str.length / 3.7);
  }

  getGraphCompleteness() {
    if (this.mode === 'dev') return 'full';
    const runtimeEdge = db.get("SELECT 1 FROM edges WHERE source = 'runtime' LIMIT 1");
    return runtimeEdge ? 'full' : 'skeleton';
  }

  /**
   * Section 8: Context Management
   * Summarizes at 80% threshold.
   */
  async checkContextLifecycle() {
    const window = this.activeModelWindow || Operator.CONTEXT_WINDOWS['default'];
    const estimatedTokens = this._estimateTokens(this.sessionHistory);
    if (estimatedTokens > window * this.contextThreshold) {
      await this.summarizeSession();
    }
  }

  async summarizeSession() {
    console.error(`[Operator] Context threshold reached. Summarizing session...`);
    const condensedCount = this.sessionHistory.length;
    const hardState = this.getHardState();
    
    // Invariant 13: Checkpoint before mutation
    stateManager.checkpoint('mirror');

    const summarizationPrompt = `Summarize the preceding session history into a concise state summary. 
Preserve all active task details, key architectural decisions, and the current Hard State Anchor. 
Condense the history into approximately 2000 tokens while maintaining causal links between events.
The output will be used as the new system context.`;

    const summary = await callModel('operator', summarizationPrompt, { sessionHistory: this.sessionHistory }, hardState);
    
    this.sessionHistory = [{ role: 'system', content: `[SESSION SUMMARY] ${summary}` }];
    this.stateSummary.progressSummary = summary.substring(0, 200);
    console.error(`[CONTEXT RESET] Session summarized at ${new Date().toISOString()}. ${condensedCount} messages condensed.`);
  }

  async processMessage(userMessage) {
    await this.checkContextLifecycle();
    const input = userMessage.trim().toLowerCase();

    // BUG-013: Intercept input if sandbox is focused
    if (this.sandboxFocus) {
      eventStore.append('SANDBOX_INPUT', 'human', { input: userMessage }, 'mirror');
      return { status: 'sandbox_intercept', message: "Input sent to sandbox." };
    }

    // State Machine Transitions
    if (input === 'go' && this.stateSummary.pendingDecision) {
      return await this.handleApproval('go');
    }

    if (input.startsWith('pin:') || input.startsWith('exclude:')) {
      // Stage 1.5 logic: update projected context (simplified for 0.7)
      return { status: 'context_updated', prompt: "Context updated. Type 'go' to proceed to Planning." };
    }

    this.sessionHistory.push({ role: 'user', content: userMessage });
    
    const classification = await this.classifyRequest(userMessage);

    if (classification.needsClarification) {
      return { needsClarification: true, question: classification.rationale };
    }

    const routing = await this.determineRouting(classification);
    this.stateSummary.pendingDecision = { classification, routing };
    this.stateSummary.worldId = classification.worldId || 'mirror';
    this.stateSummary.executorLogs = null;

    // Invariant 13: Checkpoint before state snapshot
    stateManager.checkpoint('mirror');

    // Distinguish heuristic vs. model-derived classifications in the audit trail
    const classificationSource = classification._source === 'heuristic' ? 'CLASSIFICATION_HEURISTIC' : 'CLASSIFICATION';
    const { _source, ...cleanClassification } = classification;
    eventStore.append(classificationSource, 'operator', { classification: cleanClassification, routing }, 'mirror');

    this.stateSummary.currentStage = 'classification';
    this.stateSummary.filesInScope = cleanClassification.files;
    stateManager.snapshot(this.stateSummary, 'mirror');

    // Section 8: Approval Gate (Stage 5)
    // Tier 0 skips gate. Tier 1+ enters Stage 1.5 Assumption Ledger.
    if (routing.tier > 0) {
      const stage1_5 = await this.runStage1_5(cleanClassification, routing);
      this.stateSummary.pendingDecision.ledger = stage1_5.assumptionLedger;
      
      // Section 27: Entropy-based decomposition recommendation
      if (stage1_5.assumptionLedger.entropyScore > 10) {
        stage1_5.prompt = `[HIGH ENTROPY] ${stage1_5.prompt}\nTask decomposition recommended before proceeding.`;
      }
      
      // Section 27: Blocker enforcement
      if (stage1_5.assumptionLedger.blockers.length > 0) {
        stage1_5.prompt = `[BLOCKED] ${stage1_5.prompt}\nCannot proceed until blockers are resolved.`;
      }

      return stage1_5;
    }

    return { classification: cleanClassification, routing, status: 'ready_for_planning' };
  }

  /**
   * Handles the Stage 5 Approval Gate and triggers the pipeline.
   */
  async handleApproval(decision) {
    if (this.stateSummary.pendingDecision && this.stateSummary.pendingDecision.ledger) {
      const blockers = this.stateSummary.pendingDecision.ledger.blockers;
      if (blockers.length > 0 && decision.toLowerCase() === 'go') {
        return { 
          status: 'blocked', 
          reason: `Task is BLOCKED: ${blockers.join(', ')}. Resolve blockers before typing 'go'.`,
          ledger: this.stateSummary.pendingDecision.ledger
        };
      }
    }

    const approval = await this.requestApproval(decision);
    if (!approval.approved) {
      delete this.stateSummary.pendingDecision;
      return { status: 'aborted', reason: 'Human denied approval.' };
    }

    const { classification, routing } = this.stateSummary.pendingDecision;
    delete this.stateSummary.pendingDecision;

    try {
      // Stage 3: Planning
      const planResult = await this.runStage3(classification, routing, [], this.stateSummary.executorLogs);
      let agreedPlan = planResult.plan;

      if (planResult.needsTiebreaker) {
        agreedPlan = await this.runStage3D(planResult.conflict, classification, routing);
      }

      // Stage 4: Code
      const codeResult = await this.runStage4(agreedPlan, classification, routing);
      
      // Stage 4.5: Virtual Dry Run (Placeholder for 0.8)
      const dryRun = await this.runStage4_5(codeResult.code);

      // Stage 6: Write + Validate
      const writeResult = await this.runStage6(codeResult.code, classification.files);

      if (!writeResult.validatorPassed) {
        const errorHash = require('crypto').createHash('sha256').update(writeResult.validatorOutput).digest('hex').slice(0, 16);
        eventStore.append('VALIDATION_FAILED', 'operator', { 
          files: writeResult.modifiedFiles, 
          errorHash 
        }, 'mirror');
        const err = new Error(`Validator failed: ${writeResult.validatorOutput.slice(0, 200)}...`);
        err.validatorOutput = writeResult.validatorOutput;
        throw err;
      }

      // Stage 5.5: Surface audit package to REPL — pause here.
      // REPL resolves via 'approved' → runStage8(), or 'reject' → runStage7Rollback().
      // Do NOT auto-approve, auto-rollback, or continue to Stage 11 here.
      this.stateSummary.pendingAuditContext = { classification, routing, modifiedFiles: writeResult.modifiedFiles };
      const auditPkg = await this.runStage7(writeResult);
      return {
        status: 'audit_pending',
        auditPackage: auditPkg,
        prompt: 'Audit package ready. Respond "approved" to sync state, or "reject" to roll back.'
      };
      // NOTE: Stage 11 (graph update) runs after 'approved' in runStage8(), not here.
    } catch (e) {
      console.error(`[Operator] Pipeline failure: ${e.message}`);
      
      // BUG-012: Smoke test failure loop (Recovery limit)
      if (this.stateSummary.recoveryAttempts < 3) {
        this.stateSummary.recoveryAttempts++;
        console.error(`[Operator] Attempting recovery (${this.stateSummary.recoveryAttempts}/3)...`);
        // Re-inject the pending decision into the pipeline for retry
        this.stateSummary.executorLogs = e.validatorOutput || e.message;
        this.stateSummary.pendingDecision = { classification, routing };
        return await this.handleApproval('go');
      }

      return { status: 'error', reason: `Pipeline failure after ${this.stateSummary.recoveryAttempts} recovery attempts: ${e.message}` };
    }
  }

  /**
   * Section 15: Stage 3D — Tiebreaker (Plan)
   */
  async runStage3D(conflict, classification, routing) {
    this.stateSummary.currentStage = 'tiebreaker_plan';
    const hardState = this.getHardState();
    const prompt = `Arbitrate the following plan conflict and produce a single convergent ExecutionPlan.\nConflict: ${conflict}\nTask: ${classification.rationale}\n\nReturn ONLY JSON per SPEC Section 13 (ExecutionPlan).`;
    
    const response = await callModel('tiebreaker', prompt, { classification, routing }, hardState);
    const plan = this._safeParseJSON(response);
    if (!plan) throw new Error("[Operator] Tiebreaker plan parse failure.");
    eventStore.append('TIEBREAKER_PLAN', 'operator', { plan }, 'mirror');
    return plan;
  }

  /**
   * Section 27: Pre-Execution Assumption Ledger
   * Audit every assumption before planning begins.
   */
  async generateAssumptionLedger(classification, routing, context) {
    const hardState = this.getHardState();
    const prompt = `Audit every assumption for the following task. 
  Task: ${classification.rationale}
  Files: ${classification.files.join(', ')}
  Routing Tier: ${routing.tier}

  Return ONLY a JSON object following this schema:
  {
  "assumptions": [
    {
      "id": "A1",
      "category": "Logic" | "Architecture" | "Data" | "UX" | "Security",
      "statement": "One falsifiable sentence.",
      "impact": "Critical" | "High" | "Low",
      "autonomousDefault": "Specific decision if human types go."
    }
  ],
  "blockers": ["Specific missing info preventing go"],
  "entropyScore": number
  }

  Calculate entropyScore as: (Critical × 3) + (High × 1.5) + (Low × 0.5).`;

    try {
      const response = await callModel('classifier', prompt, { classification, routing, context }, hardState);
      const ledger = this._safeParseJSON(response);

      if (!ledger || !ledger.assumptions) {
        throw new Error("[Operator] Ledger generation failed or malformed.");
      }

      // Ensure score is derived correctly if model missed it
      ledger.entropyScore = this._calculateEntropy(ledger.assumptions);
      return ledger;
    } catch (e) {
      console.error(`[Operator] Ledger generation error: ${e.message}`);
      return { assumptions: [], blockers: ["Ledger generation failed"], entropyScore: 0 };
    }
  }

  _calculateEntropy(assumptions) {
    const weights = { 'Critical': 3, 'High': 1.5, 'Low': 0.5 };
    return assumptions.reduce((sum, a) => sum + (weights[a.impact] || 0), 0);
  }

  /**
   * Section 27: Sign-Off Block Formatting
   */
  _formatSignOffBlock(ledger) {
    const critical = ledger.assumptions.filter(a => a.impact === 'Critical').map(a => a.id);
    const defaults = ledger.assumptions.map(a => a.id);

    return `
  Entropy Score: ${ledger.entropyScore}
  Blockers: ${ledger.blockers.length > 0 ? ledger.blockers.join(', ') : 'none'}
  Critical assumptions requiring confirmation: ${critical.length > 0 ? critical.join(', ') : 'none'}
  Autonomous defaults active if you type go: ${defaults.join(', ')}
  `;
  }

  /**
   * Section 15: Stage 1.5 — Human Intervention Gate
   * Section 27: Assumption Ledger
   */
  async runStage1_5(classification, routing) {
    this.stateSummary.currentStage = 'context_pinning';

    // 1. Default search for classification files or SPEC.md
    const context = await this.callMCPTool('graph_search', { pattern: classification.files[0] || 'SPEC.md' });

    // 2. Generate Section 27 Assumption Ledger
    const ledger = await this.generateAssumptionLedger(classification, routing, context);
    const signOff = this._formatSignOffBlock(ledger);

    return {
      needsApproval: true,
      stage: '1.5',
      projectedContext: context,
      assumptionLedger: ledger,
      signOffBlock: signOff,
      prompt: `Stage 1.5: Review context and Assumption Ledger.\n${signOff}\nType 'pin: [id]' to emphasize, 'exclude: [id]' to ignore, or 'go' to proceed to Planning.`
    };
  }
  /**
   * Section 15: Stage 3 — Independent Plan Derivation
   * Qualitative consensus based on Spec Adherence.
   */
  async runStage3(classification, routing, pinnedContext = [], executorLogs = null) {
    this.stateSummary.currentStage = 'planning';
    const hardState = this.getHardState();

    const planPrompt = `Derive an ExecutionPlan adhering to the Prime Directive.
Task: ${classification.rationale}
Prime Directive: ${hardState.primeDirective}
Failure Context (Retry): ${executorLogs || 'None'}
Pinned Context: ${pinnedContext.join(', ')}

Return ONLY JSON per SPEC Section 13:
{
  "intent": "Specific Spec requirement being fulfilled",
  "stateTransitions": ["Sequence of state changes"],
  "filesToChange": ["paths"],
  "subsystemsImpacted": ["names"],
  "invariantsPreserved": ["Safety rules guarded"],
  "rationale": "Why this approach?"
}`;

    // Stage 3A & 3B: Independent derivation (Blind Isolation)
    const [planARaw, planBRaw] = await Promise.all([
      callModel('architecturePlanner', planPrompt, { classification, routing }, hardState),
      callModel('componentPlanner', planPrompt, { classification, routing }, hardState)
    ]);

    const planA = this._safeParseJSON(planARaw);
    const planB = this._safeParseJSON(planBRaw);

    if (!planA || !planB) {
      throw new Error("[Operator] Planning failed: malformed plan output.");
    }

    const consensus = await this.evaluateSpecAdherence(planA, planB, hardState);
    
    eventStore.append('PLAN_CONSENSUS', 'operator', { 
      planA, 
      planB, 
      consensus 
    }, 'mirror');

    if (consensus.verdict === 'divergent') {
      this.stateSummary.currentStage = 'tiebreaker_plan';
      return { 
        needsTiebreaker: true, 
        conflict: consensus.conflict,
        rationale: "Plans diverge on load-bearing constraints or Spec interpretation."
      };
    }

    return { status: 'plan_agreed', plan: planA, consensusIntent: consensus.consensusIntent };
  }

  /**
   * Section 15: Stage 4 — Code Derivation and Consensus
   * Milestone 0.7-03 & 0.7-04.
   */
  async runStage4(plan, classification, routing) {
    this.stateSummary.currentStage = 'code_derivation';
    const hardState = this.getHardState();
    this.stateSummary.blockCounter = 0;

    while (this.stateSummary.blockCounter < 3) {
      // Stage 4A: Architecture Planner
      const plannerPrompt = `Write the implementation code for the agreed plan.\nPlan: ${JSON.stringify(plan)}\nTask: ${classification.rationale}\nFiles: ${classification.files.join(', ')}`;
      const codeA = await callModel('architecturePlanner', plannerPrompt, { plan, classification }, hardState);

      // Invariant 7: Compute Planner hashes for blindness enforcement
      const plannerHashes = computeContentHashes(codeA);
      const planHashes = computeContentHashes(JSON.stringify(plan));
      const allProtectedHashes = [...plannerHashes, ...planHashes];

      // Stage 4B: Adversarial Reviewer (blind)
      const reviewerPrompt = `Independent Code Derivation (Blind). Derive your own ExecutionPlan and write the code independently.\nTask: ${classification.rationale}\nReturn ReviewerOutput JSON.`;
      const reviewerOutputRaw = await callModel('reviewer', reviewerPrompt, { classification }, hardState, allProtectedHashes);
      const reviewerOutput = this._safeParseJSON(reviewerOutputRaw);

      if (!reviewerOutput || !reviewerOutput.independentCode) {
        console.error("[Operator] Reviewer produced malformed output. Retrying iteration.");
        continue;
      }

      // Stage 4C: Gate 2 — Code Consensus
      const consensus = await this.evaluateCodeConsensus(codeA, plan, reviewerOutput, hardState);
      
      eventStore.append('CODE_CONSENSUS', 'operator', { 
        plannerCode: codeA, 
        reviewerOutput, 
        consensus,
        iteration: this.stateSummary.blockCounter + 1
      }, 'mirror');

      if (consensus.verdict === 'pass') {
        return { status: 'code_agreed', code: codeA, consensusIntent: consensus.consensusIntent };
      }

      if (consensus.verdict === 'block') {
        this.stateSummary.blockCounter++;
        console.error(`[Operator] Code Blocked (${this.stateSummary.blockCounter}/3): ${consensus.reason}`);
      }
    }

    // Stage 4D: Tiebreaker (Code)
    return await this.runStage4D(plan, classification, routing);
  }

  /**
   * Section 15: Stage 11 — Intelligence Graph Update (Task 0.8-07)
   *
   * Called after successful code derivation (Stage 4 / 4.5).
   * 1. Ingests runtime-trace.json if the sandbox probe produced one.
   * 2. Re-indexes any files touched during this pipeline run.
   *
   * Non-fatal: failures are logged but do not block task completion.
   */
  async runStage11() {
    this.stateSummary.currentStage = 'knowledge_update';
    console.error(`[Operator] Stage 11: Intelligence Graph Update starting...`);

    try {
      // 1. Ingest runtime trace (0.8-07)
      const traceFile = 'data/runtime-trace.json';
      const traceAbsPath = path.resolve(process.cwd(), traceFile);
      if (fs.existsSync(traceAbsPath)) {
        console.error(`[Operator] Stage 11: Ingesting runtime trace from ${traceFile}...`);
        await this.callMCPTool('graph_ingest_runtime_trace', { traceFile });
      }

      // 2. Re-index files modified during this run
      const modifiedFiles = this.stateSummary.filesInScope || [];
      if (modifiedFiles.length > 0) {
        console.error(`[Operator] Stage 11: Re-indexing ${modifiedFiles.length} modified file(s)...`);
        // Capture revision before and after to verify the scan completed successfully.
        const beforeInfo = await this.callMCPTool('graph_server_info', {});
        const revBefore = JSON.parse(beforeInfo.content[0].text).index_revision;

        await this.callMCPTool('graph_update_task', { modifiedFiles });

        const afterInfo = await this.callMCPTool('graph_server_info', {});
        const revAfter = JSON.parse(afterInfo.content[0].text).index_revision;
        if (revAfter <= revBefore) {
          console.error(`[Operator] Stage 11: WARN: index_revision did not increment after graph_update_task (was ${revBefore}, still ${revAfter}). Scan may have failed.`);
        } else {
          console.error(`[Operator] Stage 11: index_revision: ${revBefore} → ${revAfter}`);
        }
      }

      // 3. Update Graph Summary (BUG-042)
      const graphSummaryResult = await this.callMCPTool('graph_search', { pattern: 'SPEC.md' });
      if (graphSummaryResult && graphSummaryResult.content && graphSummaryResult.content[0]) {
        this.stateSummary.graphSummary = graphSummaryResult.content[0].text;
      }

      console.error(`[Operator] Stage 11: Intelligence Graph Update complete.`);
    } catch (e) {
      // Stage 11 failures are non-fatal — log and continue
      console.error(`[Operator] Stage 11: Non-fatal error during graph update: ${e.message}`);
    }
  }

  async evaluateCodeConsensus(codeA, plan, reviewerOutput, hardState) {
    const auditPrompt = `Audit the Planner's code against the agreed plan and Reviewer's independent derivation.\nPlan: ${JSON.stringify(plan)}\nPlanner Code: ${codeA}\nReviewer Code: ${reviewerOutput.independentCode}\nReviewer Concerns: ${JSON.stringify(reviewerOutput.concerns)}\n\nDoes the code correctly implement state transitions? Return JSON with verdict, reason, citation, and consensusIntent.`;
    const result = await callModel('reviewer', auditPrompt, {}, hardState);
    if (process.env.MBO_DEBUG) console.error(`[DEBUG] evaluateCodeConsensus response: ${result}`);
    return this._safeParseJSON(result, { verdict: 'block', reason: 'JSON Parse Failure' });
  }

  /**
   * Section 15: Stage 4D — Tiebreaker (Code)
   * Milestone 0.7-05.
   */
  async runStage4D(plan, classification, routing) {
    this.stateSummary.currentStage = 'tiebreaker_code';
    const hardState = this.getHardState();
    let retries = 0;

    while (retries < 3) {
      const prompt = `Tiebreaker: Produce the final arbitrated code draft based on competing derivations.\nPlan: ${JSON.stringify(plan)}\nTask: ${classification.rationale}\n\nReturn the final code/diff only.`;
      const codeTied = await callModel('tiebreaker', prompt, { classification, routing }, hardState);

      // Spec Note (BUG-010): One final audit for Tiebreaker code.
      const reviewerPrompt = `Final Audit of Tiebreaker Code.\nTask: ${classification.rationale}\nCode: ${codeTied}\n\nReturn ONLY JSON verdict per SPEC Section 11.`;
      const finalAuditRaw = await callModel('reviewer', reviewerPrompt, { classification }, hardState);
      const finalAudit = this._safeParseJSON(finalAuditRaw);

      if (finalAudit && finalAudit.verdict === 'pass') {
        return { status: 'code_agreed', code: codeTied, source: 'tiebreaker' };
      }

      console.error(`[BUG-010] Tiebreaker code blocked by reviewer (Attempt ${retries + 1}/3): ${finalAudit?.reason || 'Unknown reason'}`);
      retries++;
    }

    throw new Error(`[BUG-010] Tiebreaker code consistently blocked by reviewer after 3 attempts. Escalating to human.`);
  }


  /**
   * Section 15: Stage 4.5 — Virtual Dry Run
   * Milestone 0.8 prerequisite.
   */
  async runStage4_5(code) {
    this.stateSummary.currentStage = 'dry_run';
    // Basic structural verification (syntax check)
    try {
      if (code.includes('const') || code.includes('function')) {
        // Simple heuristic for JS validity
        new Function(code.replace(/export |import /g, ''));
      }
      return { status: 'pass', checks: ['structural_syntax'] };
    } catch (e) {
      return { status: 'warn', checks: ['structural_syntax'], error: e.message };
    }
  }

  /**
   * Evaluates if two plans agree on "Load-Bearing" logic.
   * Section 15.3C: Qualitative Convergence Audit.
   */
  async evaluateSpecAdherence(planA, planB, hardState) {
    const auditPrompt = `Audit these independent plans against the Prime Directive.
Prime Directive: ${hardState.primeDirective}
Plan A: ${JSON.stringify(planA)}
Plan B: ${JSON.stringify(planB)}

Do both plans fulfill the same qualitative intent without violating project invariants?
Return JSON:
{
  "verdict": "convergent" | "divergent",
  "conflict": "Describe any contradiction in state transitions or safety logic",
  "consensusIntent": "The shared goal both plans achieve"
}`;
    const result = await callModel('classifier', auditPrompt, {}, hardState);
    if (process.env.MBO_DEBUG) console.error(`[DEBUG] evaluateSpecAdherence response: ${result}`);
    return this._safeParseJSON(result, { verdict: 'divergent', conflict: 'JSON Parse Failure' });
  }

  /**
   * Section 5: Stage 5 Approval Gate
   * Structural enforcement of human approval before mutation.
   */
  async requestApproval(decision) {
    if (decision.toLowerCase() === 'go') {
      eventStore.append('APPROVAL', 'human', { decision: 'go' }, 'mirror');
      return { approved: true };
    }
    eventStore.append('APPROVAL', 'human', { decision: 'abort' }, 'mirror');
    return { approved: false };
  }

  async shutdown() {
    if (this.mcpServer) {
      this.mcpServer.kill();
      this.mcpServer = null;
    }
    this.mcpSessionId = null;
    // Clean up persisted session — a killed server's session ID is invalid.
    try {
      require('fs').unlinkSync(path.join(getRunDir(this.mode), 'mcp.session'));
    } catch (_) {}
    // Section 17: Generate handoff on clean shutdown
    stateManager.checkpoint('mirror');
    stateManager.generateHandoff();
  }
}

module.exports = { Operator };
