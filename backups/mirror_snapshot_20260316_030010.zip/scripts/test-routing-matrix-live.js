const { spawnSync } = require('child_process');
const operator = require('../src/auth/operator');
const fs = require('fs');
const path = require('path');
const PROJECT_ROOT = path.resolve(__dirname, '..');
const manifestPath = path.join(PROJECT_ROOT, '.dev/run/mcp.json');

async function testLiveRouting() {
  if (!fs.existsSync(manifestPath)) {
    console.log('SKIP: Live MCP manifest not found. Routing matrix test skipped.');
    return;
  }

  console.log('--- Testing Live Routing Matrix ---');
  
  // Test Case 1: graph_search
  console.log('Case 1: graph_search');
  const searchResult = await operator._graphSearch('GraphStore');
  if (searchResult && Array.isArray(searchResult)) {
    console.log(`   Found ${searchResult.length} nodes.`);
  } else {
    throw new Error('graph_search failed to return results');
  }

  // Test Case 2: graph_query_impact (using a known node if search worked)
  if (searchResult.length > 0) {
    const nodeId = searchResult[0].id;
    console.log(`Case 2: graph_query_impact for ${nodeId}`);
    const impact = await operator._graphQueryImpact(nodeId);
    if (impact && impact.nodes) {
      console.log(`   Impact graph has ${impact.nodes.length} nodes.`);
    } else {
      throw new Error('graph_query_impact failed');
    }
  }

  console.log('PASS: Live routing matrix verification successful.');
}

testLiveRouting().catch(err => {
  console.error('FAIL:', err.message);
  process.exit(1);
});
