const http = require('http');
const fs = require('fs');
const path = require('path');

async function testMCP() {
  console.log('--- Testing Graph MCP Server (HTTP) ---');

  const PROJECT_ROOT = path.resolve(__dirname, '..');
  const manifestPath = path.join(PROJECT_ROOT, '.dev/run/mcp.json');

  if (!fs.existsSync(manifestPath)) {
    console.log('SKIP: MCP manifest not found. Run mbo setup first.');
    return;
  }

  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  const port = manifest.port;
  console.log(`Using live MCP server on port ${port}...`);

  function sendRequest(method, params = {}, sid = null) {
    return new Promise((resolve, reject) => {
      const payload = { jsonrpc: '2.0', id: Date.now(), method, params };
      const body = JSON.stringify(payload);
      const req = http.request({
        host: '127.0.0.1',
        port,
        path: '/mcp',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(body),
          ...(sid ? { 'mcp-session-id': sid } : {})
        },
        timeout: 10000
      }, (res) => {
        let text = '';
        res.on('data', d => text += d);
        res.on('end', () => {
          try {
            if (text.startsWith('data: ')) text = text.slice(6);
            resolve({ msg: JSON.parse(text), sid: res.headers['mcp-session-id'] });
          } catch (e) { reject(new Error(`Parse error: ${text}`)); }
        });
      });
      req.on('error', reject);
      req.on('timeout', () => { req.destroy(); reject(new Error('Request timed out')); });
      req.write(body);
      req.end();
    });
  }

  try {
    // 1. Initialize
    console.log('Step 1: Initializing...');
    const init = await sendRequest('initialize', {
      protocolVersion: '2024-11-05',
      capabilities: {},
      clientInfo: { name: 'test-client', version: '1.0.0' }
    });
    const sid = init.sid;
    console.log(`Session ID: ${sid}`);

    // 2. List Tools
    console.log('Step 2: Listing tools...');
    const tools = await sendRequest('tools/list', {}, sid);
    const toolNames = tools.msg.result.tools.map(t => t.name);
    console.log('Tools found:', toolNames);

    // 3. Call search smoke test
    console.log('Step 3: Smoke test (graph_search)...');
    const search = await sendRequest('tools/call', {
      name: 'graph_search',
      arguments: { pattern: 'GraphStore' }
    }, sid);
    console.log('Search result found:', !!search.msg.result.content);

    console.log('PASS: MCP Server HTTP smoke test successful.');
  } catch (err) {
    console.error('FAIL:', err.message);
    process.exit(1);
  }
}

testMCP().catch(console.error);
