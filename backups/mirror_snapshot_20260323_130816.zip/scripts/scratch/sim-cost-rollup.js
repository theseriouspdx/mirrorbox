'use strict';

/**
 * scripts/scratch/sim-cost-rollup.js
 * Synthetic cost rollup simulation for v0.12.01.
 * Seeds an in-memory SQLite DB with realistic token_log rows across
 * three model tiers (Gemini flash, Claude Sonnet, Claude Opus),
 * then exercises getCostRollup() and prints getStatus()-style output.
 *
 * Does NOT touch mirrorbox.db. Safe to run any time.
 */

const { DBManager } = require('../../src/state/db-manager');
const path = require('path');
const os = require('os');
const fs = require('fs');

// Spin up a throw-away DB in /tmp
const tmpDb = path.join(os.tmpdir(), `mbo-sim-${Date.now()}.db`);
const db = new DBManager(tmpDb);

// ── Synthetic data ──────────────────────────────────────────────────────────
// Modelled on a realistic Tier-2 run:
//   Classifier  → Gemini flash  (cheap, high-volume)
//   Operator    → Gemini flash
//   Planner A   → Claude Sonnet (mid-tier)
//   Planner B   → Claude Sonnet
//   Reviewer    → Gemini flash
//   Tiebreaker  → Claude Opus   (expensive, rare)

const RUN = 'sim-run-001';
let seq = 0;
const uid = () => `sim-${++seq}`;

const ROWS = [
  // role,              model,                              input,  output, cost_usd,   raw_tokens, raw_cost
  ['classifier',   'google/gemini-2.0-flash-001',          1200,   180,    0.000048,   1380, 0.000138],
  ['classifier',   'google/gemini-2.0-flash-001',          980,    140,    0.000037,   1120, 0.000112],
  ['classifier',   'google/gemini-2.0-flash-001',          1050,   160,    0.000042,   1210, 0.000121],
  ['operator',     'google/gemini-2.0-flash-001',          2200,   310,    0.000100,   2510, 0.000251],
  ['operator',     'google/gemini-2.0-flash-001',          1900,   280,    0.000086,   2180, 0.000218],
  ['reviewer',     'google/gemini-2.0-flash-001',          3100,   420,    0.000141,   3520, 0.000352],
  ['reviewer',     'google/gemini-2.0-flash-001',          2800,   390,    0.000126,   3190, 0.000319],
  ['architecturePlanner', 'anthropic/claude-3-5-sonnet',   4500,   890,    0.002025,   5390, 0.002695],
  ['componentPlanner',    'anthropic/claude-3-5-sonnet',   4200,   820,    0.001890,   5020, 0.002510],
  ['architecturePlanner', 'anthropic/claude-3-5-sonnet',   3900,   750,    0.001755,   4650, 0.002325],
  ['tiebreaker',   'anthropic/claude-opus-4',              5800,  1200,    0.015000,   7000, 0.021000],
  ['tiebreaker',   'anthropic/claude-opus-4',              4900,  1050,    0.012750,   5950, 0.017850],
];

const now = Date.now();
for (const [role, model, inp, out, cost, rawTok, rawCost] of ROWS) {
  db.logTokenUsage({
    id: uid(), runId: RUN, role, model,
    inputTokens: inp, outputTokens: out,
    costUsd: cost,
    rawTokensEstimate: rawTok,
    rawCostEstimate: rawCost,
    timestamp: now,
  });
}

// ── Run rollup ───────────────────────────────────────────────────────────────
const rollup = db.getCostRollup();
const fmt6 = v => `$${v.toFixed(6)}`;
const fmt4 = v => `$${v.toFixed(4)}`;

console.log('\n═══ getCostRollup() — synthetic simulation ═══════════════════════════\n');
console.log('By model:');
for (const r of rollup.byModel) {
  console.log(
    `  ${r.model.padEnd(40)} ${String(r.calls).padStart(3)} calls  ${fmt6(r.actualCost)}`
  );
}

console.log('\n─── Routing Cost ────────────────────────────────────────');
for (const r of rollup.byModel) {
  console.log(`  ${r.model.padEnd(38)} ${String(r.calls).padStart(4)} calls  ${fmt6(r.actualCost)}`);
}
console.log(`  ${'Actual total'.padEnd(38)} ${String(rollup.totalCalls).padStart(4)} calls  ${fmt6(rollup.actualCost)}`);
console.log(`  Counterfactual (all → ${rollup.maxRateModel})`);
console.log(`  ${''.padEnd(38)}               ${fmt6(rollup.counterfactualCost)}`);
console.log(`  ${'Routing savings'.padEnd(38)}        ${fmt6(rollup.routingSavings)}`);
console.log('─────────────────────────────────────────────────────────\n');

const pct = rollup.counterfactualCost > 0
  ? ((rollup.routingSavings / rollup.counterfactualCost) * 100).toFixed(1)
  : '0.0';
console.log(`Savings summary: ${fmt4(rollup.routingSavings)} saved vs all-Opus baseline (${pct}% reduction)`);
console.log(`Total calls: ${rollup.totalCalls}  |  Models used: ${rollup.byModel.length}`);

// Cleanup
db.close ? db.close() : null;
try { fs.unlinkSync(tmpDb); } catch (_) {}
