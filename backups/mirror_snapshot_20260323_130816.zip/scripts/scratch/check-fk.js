const Database = require('better-sqlite3');
const path = require('path');
const dbPath = path.join(process.cwd(), '.mbo/mirrorbox.db');
const db = new Database(dbPath);
console.log('PRAGMA foreign_keys:', db.prepare('PRAGMA foreign_keys').get());
