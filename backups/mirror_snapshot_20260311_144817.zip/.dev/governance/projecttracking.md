# projecttracking.md
## Mirror Box Orchestrator — Build Tracking

**Current Milestone:** 1.0 — Production Alpha [IN PROGRESS]
**Next Action:** 1.0-09 — Sovereign Loop

---

## CLOSED MILESTONES
| Milestone | Description | Status |
|-----------|-------------|--------|
| 0.1 | Environment | COMPLETED |
| 0.2 | Auth and Model Routing | COMPLETED |
| 0.3 | State + Event Foundation | COMPLETED |
| 0.4A | Intelligence Graph: Tree-sitter Skeleton | COMPLETED |
| 0.4B | Intelligence Graph: LSP Enrichment | COMPLETED |
| 0.5 | callModel + Firewall | COMPLETED |
| 0.6 | Operator + Session | COMPLETED |
| 0.7 | DID Pipeline | COMPLETED |
| 0.8 | Sandbox | COMPLETED |
| 0.9 | Sovereign Factory | COMPLETED |

---

## MILESTONE 1.0 — Production Alpha [IN PROGRESS]
| Task ID | Task Description | Status |
|---------|------------------|--------|
| 1.0-01 | Global Integrity & Bug-Fix Patch (BUG-009, BUG-037) | COMPLETED |
| 1.0-02 | Initialize Subject World (Target Codebase) logic | COMPLETED |
| 1.0-03 | The Relay — UDS cross-world telemetry (Subject → Mirror EventStore) | COMPLETED |
| 1.0-04 | The Pile — Promotion engine (Mirror → Subject, Merkle-validated) | COMPLETED |
| 1.0-05 | The Guard — Relay integrity gatekeeper (scope + chain validation) | COMPLETED |
| 1.0-06 | Stage 6/7/8 wiring — handshake.py writes, validator.py, test runner | COMPLETED |
| 1.0-07 | Subject World graph routing — Stage 2 routes by world_id to correct DB | COMPLETED |
| 1.0-08 | External Invariant Test Suite — black-box, all Section 22 invariants | COMPLETED |
| 1.0-MCP-01 | MCP Layer 1: Fix signal trap stderr redirect + close fd 3 (BUG-049) | COMPLETED |
| 1.0-MCP-02 | MCP Layer 2: EPIPE guard in mcp-server.js | COMPLETED |
| 1.0-MCP-03 | MCP Layer 3: Startup sentinel file (.dev/run/mcp.ready) | COMPLETED |
| 1.0-MCP-04 | MCP Layer 4: launchd plist (com.mbo.mcp) | COMPLETED |
| 1.0-MCP-05 | MCP Layer 5: Transparent session recovery on stale session-id | COMPLETED |
| 1.0-09 | Sovereign Loop — MBO patches itself end-to-end (1.0 close condition) | OPEN |
| 1.0-10 | Stage 1.5 Assumption Ledger — implement Section 27 protocol in operator.js pipeline | OPEN |
